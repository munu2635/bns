#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <opencv2/core/mat.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

using namespace cv;
using namespace std;

//HSV Color red_signal
/*
#define R_H_LOW 170 //or 0
#define R_H_HIGH 179 // 180 or 10
#define R_S_LOW 50 //50~70
#define R_S_HIGH 255
#define R_V_LOW 50
#define R_V_HIGH 255
*/
#define R_H_LOW 0 //or 0
#define R_H_HIGH 21 // 180 or 10
#define R_S_LOW 50 //50~70
#define R_S_HIGH 255
#define R_V_LOW 150
#define R_V_HIGH 255


//HSV Color green_signal
/*
#define G_H_LOW 45
#define G_H_HIGH 75
#define G_S_LOW 100
#define G_S_HIGH 255
#define G_V_LOW 50
#define G_V_HIGH 255
*/
#define G_H_LOW 45
#define G_H_HIGH 100
#define G_S_LOW 100
#define G_S_HIGH 255
#define G_V_LOW 100
#define G_V_HIGH 255


//HSV Color yellow stone
#define Y_H_LOW 20
#define Y_H_HIGH 30
#define Y_S_LOW 100
#define Y_S_HIGH 255
#define Y_V_LOW 100
#define Y_V_HIGH 255

bool r_flag = true;
bool g_flag = true;
bool y_flag = true;

timer_t firstTimerID;


static void timerHandler(int sig, siginfo_t *si, void *uc)
{
	timer_t *tidp;
	tidp = (void**)(si->si_value.sival_ptr);

	if (*tidp == firstTimerID)
		printf("2ms\n");
	/*
		else if ( *tidp == secondTimerID )
			printf("10ms\n");

		else if ( *tidp == thirdTimerID )
			printf("100ms\n");
	*/
	r_flag = true;
}

static int makeTimer(timer_t *timerID, int expireMS, int intervalMS)
{
	struct sigevent te;
	struct itimerspec its;
	struct itimerspec its2;

	struct sigaction sa;
	int sigNo = SIGRTMIN;

	/* Set up signal handler. */
	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = timerHandler;
	sigemptyset(&sa.sa_mask);

	if (sigaction(sigNo, &sa, NULL) == -1) {
		perror("sigaction");
	}

	/* Set and enable alarm */
	te.sigev_notify = SIGEV_SIGNAL;
	te.sigev_signo = sigNo;
	te.sigev_value.sival_ptr = timerID;
	timer_create(CLOCK_REALTIME, &te, timerID);

	its.it_interval.tv_sec = 1;
	its.it_interval.tv_nsec = 0;// intervalMS * 1000000;
	its.it_value.tv_sec = 20;
	its.it_value.tv_nsec = 0;// expireMS * 1000000;

	its2.it_interval.tv_sec = 20;
	its2.it_interval.tv_nsec = 0;// intervalMS * 1000000;
	its2.it_value.tv_sec = 20;
	its2.it_value.tv_nsec = 0;// expireMS * 1000000;

   // timer_settime(*timerID, 0, &its, NULL);
	timer_settime(*timerID, 0, &its, NULL);

	return 1;
}



int playSound(char *filename) {
	char command[256];
	int status;

	/* create command to execute */
	sprintf(command, "aplay -c 1 -q -t wav %s", filename);

	/* play sound */
	status = system(command);

	return status;
}


int main()
{

	time_t a_r, a_g, a_y;
	time_t b_r, b_g, b_y;
	struct tm a_r_tm, a_g_tm, a_y_tm;
	struct tm b_r_tm, b_g_tm, b_y_tm;


	//연결되어 있는 웹캠 열기
	VideoCapture cap(0);

	//웹캡에서 캡처되는 이미지 크기를 320x240으로 지정  
	cap.set(CAP_PROP_FRAME_WIDTH, 600);
	cap.set(CAP_PROP_FRAME_HEIGHT, 480);

	//
	if (!cap.isOpened())
	{
		cout << "Webcam is not Open!." << endl;
		return -1;
	}

	while (true)
	{

		//웹캠에서 캡처되는 속도 30 fps  
		Mat img_input, img_hsv_r, img_binary_r;
		Mat img_hsv_g, img_binary_g;
		Mat img_hsv_y, img_binary_y;

		//카메라로부터 이미지를 가져옴 
		bool ret = cap.read(img_input);

		if (!ret)
		{
			cout << "image isn't read from camera!." << endl;
			break;
		}

		//HSV로 변환
		cvtColor(img_input, img_hsv_r, COLOR_BGR2HSV);
		cvtColor(img_input, img_hsv_g, COLOR_BGR2HSV);
		cvtColor(img_input, img_hsv_y, COLOR_BGR2HSV);

		//지정한 HSV 범위를 이용하여 영상을 이진화
		inRange(img_hsv_r, Scalar(R_H_LOW, R_S_LOW, R_V_LOW), Scalar(R_H_HIGH, R_V_HIGH, R_S_HIGH), img_binary_r);

		inRange(img_hsv_g, Scalar(G_H_LOW, G_S_LOW, G_V_LOW), Scalar(G_H_HIGH, G_V_HIGH, G_S_HIGH), img_binary_g);

		inRange(img_hsv_y, Scalar(Y_H_LOW, Y_S_LOW, Y_V_LOW), Scalar(Y_H_HIGH, Y_V_HIGH, Y_S_HIGH), img_binary_y);


		//원본이미지에 잡을들을 제거, 팽창을 통해 객체의 빈부분이 채짐워
		//morphological opening 작은 점들을 제거
		//침식 erode : 필터영역내 픽셀 중 최소 픽셀값을 현재 픽셀값에 대입
		erode(img_binary_r, img_binary_r, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		erode(img_binary_g, img_binary_g, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		erode(img_binary_y, img_binary_y, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		//dilate : 영상팽창
		//팽창 : 필터 영역 내 픽셀 중 최대 픽셀값을 현재 픽셀값에 대입
		dilate(img_binary_r, img_binary_r, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		dilate(img_binary_g, img_binary_g, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		dilate(img_binary_y, img_binary_y, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));



		//morphological closing 영역의 구멍 메우기 
		dilate(img_binary_r, img_binary_r, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
		erode(img_binary_r, img_binary_r, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		dilate(img_binary_g, img_binary_g, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
		erode(img_binary_g, img_binary_g, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		dilate(img_binary_y, img_binary_y, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
		erode(img_binary_y, img_binary_y, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));


		//라벨링 : 이진화 한 이미지엣 형체를 알아보기 위해 같은 픽셀값들끼리
		//그룹화해 번호를 매긴 것을 라벨링이라고함
		Mat img_labels_r, stats_r, centroids_r;
		Mat img_labels_g, stats_g, centroids_g;
		Mat img_labels_y, stats_y, centroids_y;

		int numOfLables_r = connectedComponentsWithStats(img_binary_r, img_labels_r, stats_r, centroids_r, 8, CV_32S);

		int numOfLables_g = connectedComponentsWithStats(img_binary_g, img_labels_g, stats_g, centroids_g, 8, CV_32S);

		int numOfLables_y = connectedComponentsWithStats(img_binary_y, img_labels_y, stats_y, centroids_y, 8, CV_32S);


		//영역박스 그리기
		int max_r = -1, idx_r = 0;
		for (int j = 1; j < numOfLables_r; j++) {
			int area = stats_r.at<int>(j, CC_STAT_AREA);
			int left_r = stats_r.at<int>(j, CC_STAT_LEFT);
			int top_r = stats_r.at<int>(j, CC_STAT_TOP);
			int width_r = stats_r.at<int>(j, CC_STAT_WIDTH);
			int height_r = stats_r.at<int>(j, CC_STAT_HEIGHT);

			if (max_r < area)
			{
				max_r = area;
				idx_r = j;
			}


			//rectangle( img_input, Point(left_r,top_r), Point(left_r+width_r,top_r+height_r), Scalar(0,0,255),1 );  

			//putText(img_input, to_string(j), Point(left_r + 20, top_r + 20), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 0), 2);

			// putText(img_input, to_string(width_r*height_r), Point(left_r + 20, top_r -30), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 0), 2);

					// printf("red area : %d\n",width_r*height_r);


		}


		//영역박스 그리기
		int max_g = -1, idx_g = 0;
		for (int j = 1; j < numOfLables_g; j++) {
			int area = stats_g.at<int>(j, CC_STAT_AREA);
			int left_g = stats_g.at<int>(j, CC_STAT_LEFT);
			int top_g = stats_g.at<int>(j, CC_STAT_TOP);
			int width_g = stats_g.at<int>(j, CC_STAT_WIDTH);
			int height_g = stats_g.at<int>(j, CC_STAT_HEIGHT);

			if (max_r < area)
			{
				max_g = area;
				idx_g = j;
			}

			//rectangle( img_input, Point(left_g,top_g), Point(left_g+width_g,top_g+height_g), Scalar(0,0,255),1 );  
			//putText(img_input, to_string(j*10), Point(left_g + 20, top_g + 20), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 0), 2);
			//printf("green  area : %d\n",width_g*height_g);
		}


		//영역박스 그리기
		int max_y = -1, idx_y = 0;
		for (int j = 1; j < numOfLables_y; j++) {
			int area = stats_y.at<int>(j, CC_STAT_AREA);
			int left_y = stats_y.at<int>(j, CC_STAT_LEFT);
			int top_y = stats_y.at<int>(j, CC_STAT_TOP);
			int width_y = stats_y.at<int>(j, CC_STAT_WIDTH);
			int height_y = stats_y.at<int>(j, CC_STAT_HEIGHT);

			if (max_y < area)
			{
				max_y = area;
				idx_y = j;
			}

			//rectangle( img_input, Point(left_y,top_y), Point(left_y+width_y,top_y+height_y), Scalar(0,0,255),1 );  
		//	putText(img_input, to_string(j*100), Point(left_y + 20, top_y + 20), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 0, 0), 2);
			//printf("yellow area : %d\n",width_y*height_y);
		}


		int left_r = stats_r.at<int>(idx_r, CC_STAT_LEFT);
		int top_r = stats_r.at<int>(idx_r, CC_STAT_TOP);
		int width_r = stats_r.at<int>(idx_r, CC_STAT_WIDTH);
		int height_r = stats_r.at<int>(idx_r, CC_STAT_HEIGHT);
		
		if( width_r*height_r < 70000 )	
		rectangle(img_input, Point(left_r, top_r), Point(left_r + width_r, top_r + height_r), Scalar(0, 0, 255), 1);

		int left_y = stats_y.at<int>(idx_y, CC_STAT_LEFT);
		int top_y = stats_y.at<int>(idx_y, CC_STAT_TOP);
		int width_y = stats_y.at<int>(idx_y, CC_STAT_WIDTH);
		int height_y = stats_y.at<int>(idx_y, CC_STAT_HEIGHT);

		if( width_y*height_y < 70000 )  
		rectangle(img_input, Point(left_y, top_y), Point(left_y + width_y, top_y + height_y), Scalar(0, 0, 255), 1);

		int left_g = stats_g.at<int>(idx_g, CC_STAT_LEFT);
		int top_g = stats_g.at<int>(idx_g, CC_STAT_TOP);
		int width_g = stats_g.at<int>(idx_g, CC_STAT_WIDTH);
		int height_g = stats_g.at<int>(idx_g, CC_STAT_HEIGHT);

		if( width_g*height_g < 70000 )  
		rectangle(img_input, Point(left_g, top_g), Point(left_g + width_g, top_g + height_g), Scalar(0, 0, 255), 1);



		imshow("binary_r", img_binary_r);
		imshow("binary_g", img_binary_g);
		imshow("binary_y", img_binary_y);
		imshow("origin", img_input);


		if (r_flag) {
			if (width_r*height_r > 8000 && width_r*height_r < 288000) {

				a_r = time(NULL);
				a_r_tm = *localtime(&a_r);

				playSound("/home/cnn/traffic/red.wav");

				printf("Red Detected!!");
				printf("\n");
				r_flag = false; //빨강 사각형의 크기를 설정해주면 좋은점 신호등이 멀리있는데서 빨간색 인식하자마자 소리나오면 안좋음
						//예를 들어 전방 1m에 들어오면 소리 출력해준다고 할때 보이는 신호등의 사각형크기를 if에 넣어주면 좋을듯
			}
		}
		if (!r_flag) {
			b_r = time(NULL);
			b_r_tm = *localtime(&b_r);

			int d_diff = difftime(b_r, a_r);
			int tm_day = d_diff / (60 * 60 * 24);
			d_diff = d_diff - (tm_day * 60 * 60 * 24);

			int tm_hour = d_diff / (60 * 60);
			d_diff = d_diff - (tm_hour * 60 * 60);

			int tm_min = d_diff / 60;
			d_diff = d_diff - (tm_min * 60);

			int tm_sec = d_diff;

			if (tm_sec > 20) {
				printf("Red 20초 경과\n");
				r_flag = true;
			}
		}

		if (g_flag) {
			if (width_g*height_g > 8000 && width_g*height_g < 288000) {
				a_g = time(NULL);
				a_g_tm = *localtime(&a_g);


				printf("Green Detected!!\n");
				playSound("/home/cnn/traffic/green.wav");
				printf("\n");
				g_flag = false;
			}
		}

		if (!g_flag) {
			b_g = time(NULL);
			b_g_tm = *localtime(&b_g);

			int d_diff = difftime(b_g, a_g);
			int tm_day = d_diff / (60 * 60 * 24);
			d_diff = d_diff - (tm_day * 60 * 60 * 24);

			int tm_hour = d_diff / (60 * 60);
			d_diff = d_diff - (tm_hour * 60 * 60);

			int tm_min = d_diff / 60;
			d_diff = d_diff - (tm_min * 60);

			int tm_sec = d_diff;

			if (tm_sec > 20) {
				printf("Green : 20초 경과\n");
				g_flag = true;
			}
		}



		if (y_flag) {
			if (width_y*height_y > 8000 && width_y*height_y < 288000) {

				a_y = time(NULL);
				a_y_tm = *localtime(&a_y);

				printf("Yellow Detected!!\n");
				playSound("/home/cnn/traffic/green.wav");
				printf("\n");
				y_flag = false;
			}
		}
		if (!y_flag) {
			b_y = time(NULL);
			b_y_tm = *localtime(&b_y);

			int d_diff = difftime(b_y, a_y);
			int tm_day = d_diff / (60 * 60 * 24);
			d_diff = d_diff - (tm_day * 60 * 60 * 24);

			int tm_hour = d_diff / (60 * 60);
			d_diff = d_diff - (tm_hour * 60 * 60);

			int tm_min = d_diff / 60;
			d_diff = d_diff - (tm_min * 60);

			int tm_sec = d_diff;

			if (tm_sec > 20) {
				printf("Yellow 20초 경과\n");
				y_flag = true;
			}
		}
		//makeTimer(&firstTimerID, 900,900 ); //2ms
		//ESC키 누르면 프로그램 종료
		if (waitKey(1) == 27)
			break;
	}

	return 0;
}
